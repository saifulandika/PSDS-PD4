# Pejuang_Data_KD_4.0
Sebuah Repositori GITHub saya khusus untuk Program PSDS 4.0 kelas dasar
